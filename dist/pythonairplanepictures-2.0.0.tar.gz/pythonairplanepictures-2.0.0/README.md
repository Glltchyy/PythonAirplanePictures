## PythonAirplanePictures
A python module that gets images from [airplane-pictures.net]

pip install pythonairplanepictures

Functions:
- getRandomImage(amountOfImages, download, printOutput) # Gets a random image
- getRandomPage(AmountOfPages, Download, PrintOutput) # Gets a random page
- getTopPages(AmountOfPages, Download, PrintOutput) # Gets the top pages

Python dependicies used:
- requests
- random
- os
- re