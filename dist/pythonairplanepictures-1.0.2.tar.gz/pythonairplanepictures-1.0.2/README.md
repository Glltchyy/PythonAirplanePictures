## PythonAirplaneDownloader
A python module that gets images from [airplane-pictures.net]

Functions:
- getRandomPage(AmountOfPages, Download, PrintOutput) # Downloads a random page
- getTopPages(AmountOfPages, Download, PrintOutput) # Downloads the top pages

Python dependicies used:
- requests
- random
- os
- re